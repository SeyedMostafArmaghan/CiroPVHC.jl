module DSOVPPACMapStage0

using CiroPVHC
using Dates
using Printf

const PILOT_DATES = (Date(2012, 10, 15), Date(2012, 10, 16))
const EXPECTED_INTERVALS = 96
const ROOT_VOLTAGE_PU = 1.00
const VMIN_PU = 0.90
const VMAX_PU = 1.05
const BASE_MVA = 10.0
const BASE_KW = 10_000.0
const PRIMARY_TOLERANCE_PU = 1e-11
const PRIMARY_MAXIMUM_ITERATIONS = 2000
const REPLAY_TOLERANCE_PU = 1e-12
const REPLAY_MAXIMUM_ITERATIONS = 4000
const DAMPING = 0.70
const RESIDUAL_TOLERANCE_PU = 1e-5
const REPLAY_VOLTAGE_MATCH_TOLERANCE_PU = 2e-5
const REPLAY_SUBSTATION_MATCH_TOLERANCE_KW = 5e-2
const SAMPLE_COUNT = 1000
const INJECTION_MIN_KW = -2500.0
const INJECTION_MAX_KW = 6500.0

struct PilotNetwork
    buses::Vector{CiroPVHC.Bus}
    branches::Vector{CiroPVHC.Branch}
    topology::Any
    impedance_pu::Vector{ComplexF64}
end

function load_profile(repository_root::AbstractString)
    path = joinpath(
        repository_root,
        "data_processed",
        "ausgrid",
        "ausgrid_halfhour_normalized.csv",
    )
    return CiroPVHC.read_s1b_profile(path)
end

function select_pilot_indices(profile)
    indices = findall(timestamp -> Date(timestamp) in PILOT_DATES, profile.timestamps)
    length(indices) == EXPECTED_INTERVALS || throw(ArgumentError(
        "pilot window must contain exactly $EXPECTED_INTERVALS intervals; found $(length(indices))",
    ))
    length(unique(profile.timestamps[indices])) == EXPECTED_INTERVALS ||
        throw(ArgumentError("pilot window contains duplicate intervals"))
    all(diff(profile.timestamps[indices]) .== Minute(30)) ||
        throw(ArgumentError("pilot window contains a missing or non-half-hour interval"))
    counts = [count(i -> Date(profile.timestamps[i]) == day, indices) for day in PILOT_DATES]
    counts == [48, 48] || throw(ArgumentError(
        "pilot dates must each contain 48 intervals; found $counts",
    ))
    all(isfinite, profile.load_multiplier[indices]) ||
        throw(ArgumentError("pilot load factors contain nonfinite values"))
    all(isfinite, profile.pv_profile[indices]) ||
        throw(ArgumentError("pilot PV factors contain nonfinite values"))
    Dates.format(profile.timestamps[first(indices)], dateformat"yyyy-mm-dd HH:MM:SS") ==
        "2012-10-15 00:00:00" || throw(ArgumentError("pilot start timestamp mismatch"))
    Dates.format(profile.timestamps[last(indices)], dateformat"yyyy-mm-dd HH:MM:SS") ==
        "2012-10-16 23:30:00" || throw(ArgumentError("pilot end timestamp mismatch"))
    return indices
end

function build_pilot_network()
    buses, branches = CiroPVHC.build_ieee33_network()
    topology = CiroPVHC._s0_unconstrained_topology(buses, branches; root_bus=1)
    bus_by_id = Dict(bus.id => bus for bus in buses)
    branch_by_id = Dict(branch.id => branch for branch in branches)
    impedance_pu = zeros(ComplexF64, length(branches))
    for branch_id in eachindex(impedance_pu)
        branch = branch_by_id[branch_id]
        from_bus = topology.branch_from[branch_id]
        zbase_ohm = bus_by_id[from_bus].base_kv^2 / BASE_MVA
        impedance_pu[branch_id] = complex(branch.r_ohm, branch.x_ohm) / zbase_ohm
    end
    all(bus -> bus.base_kv == 12.66, buses) ||
        throw(ArgumentError("IEEE 33-bus base voltage is not uniformly 12.66 kV"))
    all(branch -> branch.smax_kva == 0.0, branches) ||
        throw(ArgumentError("unexpected nonzero branch rating in the pilot network"))
    return PilotNetwork(buses, branches, topology, impedance_pu)
end

function primary_power_flow(
    network::PilotNetwork,
    load_multiplier::Real,
    p13_vpp_kw::Real,
    p30_vpp_kw::Real;
    initial_voltage::Union{Nothing,Vector{ComplexF64}}=nothing,
    tolerance_pu::Real=PRIMARY_TOLERANCE_PU,
    maximum_iterations::Integer=PRIMARY_MAXIMUM_ITERATIONS,
    damping::Real=DAMPING,
)
    load_scale = Float64(load_multiplier)
    isfinite(load_scale) && load_scale >= 0.0 ||
        throw(ArgumentError("load multiplier must be finite and nonnegative"))
    all(isfinite, (p13_vpp_kw, p30_vpp_kw)) ||
        throw(ArgumentError("VPP injections must be finite"))
    maximum_iterations > 0 || throw(ArgumentError("maximum iterations must be positive"))
    0.0 < damping <= 1.0 || throw(ArgumentError("damping must lie in (0, 1]"))

    net_demand_pu = zeros(ComplexF64, length(network.buses))
    for bus in network.buses
        injection_kw = bus.id == 13 ? Float64(p13_vpp_kw) :
                       bus.id == 30 ? Float64(p30_vpp_kw) : 0.0
        net_demand_pu[bus.id] = complex(
            bus.pd_kw * load_scale - injection_kw,
            bus.qd_kvar * load_scale,
        ) / BASE_KW
    end

    voltage = initial_voltage === nothing ?
              fill(complex(ROOT_VOLTAGE_PU, 0.0), length(network.buses)) :
              copy(initial_voltage)
    length(voltage) == length(network.buses) ||
        throw(ArgumentError("initial-voltage vector length mismatch"))
    voltage[network.topology.root_bus] = complex(ROOT_VOLTAGE_PU, 0.0)
    converged = false
    iterations = 0
    final_update = Inf
    for iteration in 1:Int(maximum_iterations)
        iterations = iteration
        currents = CiroPVHC._s0_unconstrained_branch_currents(
            network.topology,
            voltage,
            net_demand_pu,
        )
        currents === nothing && break
        branch_current, _ = currents
        fixed_voltage = CiroPVHC._s0_unconstrained_forward_voltage(
            network.topology,
            network.impedance_pu,
            branch_current,
            ROOT_VOLTAGE_PU,
        )
        final_update = maximum(abs.(fixed_voltage .- voltage))
        isfinite(final_update) || break
        voltage .= Float64(damping) .* fixed_voltage .+
                   (1.0 - Float64(damping)) .* voltage
        voltage[network.topology.root_bus] = complex(ROOT_VOLTAGE_PU, 0.0)
        if final_update <= Float64(tolerance_pu)
            voltage .= fixed_voltage
            converged = true
            break
        end
    end

    magnitudes = abs.(voltage)
    if !converged
        return (
            converged=false,
            iterations=iterations,
            voltage_complex_pu=voltage,
            voltage_pu=magnitudes,
            minimum_voltage_pu=minimum(magnitudes),
            minimum_voltage_bus=argmin(magnitudes),
            maximum_voltage_pu=maximum(magnitudes),
            maximum_voltage_bus=argmax(magnitudes),
            substation_p_kw=NaN,
            substation_q_kvar=NaN,
            active_losses_kw=NaN,
            reactive_losses_kvar=NaN,
            maximum_voltage_equation_residual_pu=Inf,
        )
    end

    branch_current, _ = something(CiroPVHC._s0_unconstrained_branch_currents(
        network.topology,
        voltage,
        net_demand_pu,
    ))
    fixed_voltage = CiroPVHC._s0_unconstrained_forward_voltage(
        network.topology,
        network.impedance_pu,
        branch_current,
        ROOT_VOLTAGE_PU,
    )
    voltage_residual = maximum(abs.(fixed_voltage .- voltage))
    branch_power = zeros(ComplexF64, length(network.branches))
    losses = 0.0 + 0.0im
    for branch_id in eachindex(branch_current)
        from_bus = network.topology.branch_from[branch_id]
        branch_power[branch_id] =
            voltage[from_bus] * conj(branch_current[branch_id]) * BASE_KW
        losses += network.impedance_pu[branch_id] * abs2(branch_current[branch_id]) * BASE_KW
    end
    root_branches = [
        network.topology.parent_branch[child]
        for child in network.topology.children[network.topology.root_bus]
    ]
    substation = sum(branch_power[root_branches])
    magnitudes = abs.(voltage)
    return (
        converged=true,
        iterations=iterations,
        voltage_complex_pu=voltage,
        voltage_pu=magnitudes,
        minimum_voltage_pu=minimum(magnitudes),
        minimum_voltage_bus=argmin(magnitudes),
        maximum_voltage_pu=maximum(magnitudes),
        maximum_voltage_bus=argmax(magnitudes),
        substation_p_kw=real(substation),
        substation_q_kvar=imag(substation),
        active_losses_kw=real(losses),
        reactive_losses_kvar=imag(losses),
        maximum_voltage_equation_residual_pu=voltage_residual,
    )
end

function replay_status(primary, replay)
    !replay.converged && return "NONCONVERGED"
    !replay.phasor_recoverable && return "PHASOR_NOT_RECOVERABLE"
    (!isfinite(replay.maximum_equation_residual) ||
     !isfinite(replay.maximum_scaled_residual) ||
     replay.maximum_equation_residual > RESIDUAL_TOLERANCE_PU ||
     replay.maximum_scaled_residual > RESIDUAL_TOLERANCE_PU) &&
        return "RESIDUAL_FAILED"
    voltage_difference = maximum(abs.(primary.voltage_pu .- replay.voltage_pu))
    substation_difference = abs(primary.substation_p_kw - replay.substation_p_kw)
    (voltage_difference > REPLAY_VOLTAGE_MATCH_TOLERANCE_PU ||
     substation_difference > REPLAY_SUBSTATION_MATCH_TOLERANCE_KW) &&
        return "STATE_MISMATCH"
    return "PASSED"
end

function evaluate_point(
    network::PilotNetwork,
    profile,
    profile_index::Integer,
    p13_vpp_kw::Real,
    p30_vpp_kw::Real;
    initial_voltage::Union{Nothing,Vector{ComplexF64}}=nothing,
    warm_start_source::AbstractString="flat_start",
    primary_maximum_iterations::Integer=PRIMARY_MAXIMUM_ITERATIONS,
)
    started_ns = time_ns()
    primary = primary_power_flow(
        network,
        profile.load_multiplier[profile_index],
        p13_vpp_kw,
        p30_vpp_kw;
        initial_voltage=initial_voltage,
        maximum_iterations=primary_maximum_iterations,
    )
    capacities_kw = Dict(13 => Float64(p13_vpp_kw), 30 => Float64(p30_vpp_kw))
    replay = CiroPVHC.replay_s1b_interval(
        network.buses,
        network.branches,
        profile.load_multiplier[profile_index],
        1.0,
        capacities_kw;
        base_mva=BASE_MVA,
        root_voltage_pu=ROOT_VOLTAGE_PU,
        vmin_pu=VMIN_PU,
        vmax_pu=VMAX_PU,
        tolerance_pu=REPLAY_TOLERANCE_PU,
        voltage_tolerance_pu=0.0,
        residual_tolerance_pu=RESIDUAL_TOLERANCE_PU,
        maximum_iterations=REPLAY_MAXIMUM_ITERATIONS,
        damping=DAMPING,
    )
    status = primary.converged ? replay_status(primary, replay) : "PRIMARY_NOT_CONVERGED"
    classification = if !primary.converged || status != "PASSED"
        "UNKNOWN_SOLVER"
    elseif replay.minimum_voltage_pu < VMIN_PU || replay.maximum_voltage_pu > VMAX_PU
        "INFEASIBLE_VOLTAGE"
    else
        "FEASIBLE"
    end
    runtime_seconds = (time_ns() - started_ns) / 1e9
    voltage_difference = primary.converged && replay.converged ?
                         maximum(abs.(primary.voltage_pu .- replay.voltage_pu)) : Inf
    return (
        timestamp=Dates.format(
            profile.timestamps[profile_index],
            dateformat"yyyy-mm-dd HH:MM:SS",
        ),
        p13_vpp_kw=Float64(p13_vpp_kw),
        p30_vpp_kw=Float64(p30_vpp_kw),
        q13_vpp_kvar=0.0,
        q30_vpp_kvar=0.0,
        classification=classification,
        solver_status=primary.converged ? "CONVERGED" : "NONCONVERGED",
        replay_status=status,
        maximum_absolute_residual=replay.maximum_equation_residual,
        maximum_scaled_residual=replay.maximum_scaled_residual,
        minimum_voltage_pu=replay.minimum_voltage_pu,
        minimum_voltage_bus=replay.minimum_voltage_bus,
        maximum_voltage_pu=replay.maximum_voltage_pu,
        maximum_voltage_bus=replay.maximum_voltage_bus,
        substation_p_kw=replay.substation_p_kw,
        substation_q_kvar=replay.substation_q_kvar,
        active_losses_kw=replay.active_losses_kw,
        reactive_losses_kvar=replay.reactive_losses_kvar,
        warm_start_source=String(warm_start_source),
        runtime_seconds=runtime_seconds,
        solver_iterations=primary.iterations,
        replay_iterations=replay.iterations,
        primary_replay_max_voltage_difference_pu=voltage_difference,
        primary_voltage_equation_residual_pu=
            primary.maximum_voltage_equation_residual_pu,
        primary_voltage_complex_pu=primary.voltage_complex_pu,
    )
end

function halton(index::Integer, base::Integer)
    index >= 1 || throw(ArgumentError("Halton index must be positive"))
    base >= 2 || throw(ArgumentError("Halton base must be at least two"))
    value = 0.0
    fraction = 1.0 / base
    remaining = Int(index)
    while remaining > 0
        value += fraction * (remaining % base)
        remaining ÷= base
        fraction /= base
    end
    return value
end

function sample_plan(indices::AbstractVector{<:Integer}; count::Integer=SAMPLE_COUNT)
    count >= length(indices) || throw(ArgumentError(
        "sample count must include one zero-injection reference per interval",
    ))
    span = INJECTION_MAX_KW - INJECTION_MIN_KW
    rows = NamedTuple[]
    for sample_id in 1:Int(count)
        local_interval = mod1(sample_id, length(indices))
        if sample_id <= length(indices)
            p13, p30 = 0.0, 0.0
        else
            sequence_index = sample_id - length(indices)
            p13 = INJECTION_MIN_KW + span * halton(sequence_index, 2)
            p30 = INJECTION_MIN_KW + span * halton(sequence_index, 3)
        end
        push!(rows, (
            sample_id=sample_id,
            local_interval=local_interval,
            profile_index=Int(indices[local_interval]),
            p13_vpp_kw=p13,
            p30_vpp_kw=p30,
        ))
    end
    return rows
end

function nearest_feasible_start(feasible_starts, p13::Float64, p30::Float64)
    isempty(feasible_starts) && return nothing, "flat_start"
    distances = [
        hypot(start.p13_vpp_kw - p13, start.p30_vpp_kw - p30)
        for start in feasible_starts
    ]
    selected = feasible_starts[argmin(distances)]
    source = @sprintf(
        "nearest_feasible_sample_%d_distance_%.6f_kw",
        selected.sample_id,
        minimum(distances),
    )
    return selected.voltage, source
end

function process_cpu_seconds()
    ticks = Float64(ccall(:clock, Clong, ()))
    ticks_per_second = Sys.iswindows() ? 1_000.0 : 1_000_000.0
    return ticks / ticks_per_second
end

function csv_value(value)
    if value isa AbstractString
        escaped = replace(value, "\"" => "\"\"")
        return occursin(r"[,\"]", escaped) ? "\"$escaped\"" : escaped
    elseif value isa Float64
        return isfinite(value) ? @sprintf("%.12g", value) : string(value)
    end
    return string(value)
end

function write_namedtuple_csv(path::AbstractString, columns, rows)
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join((csv_value(getproperty(row, column)) for column in columns), ','))
        end
    end
    return path
end

function benchmark_columns()
    return (
        :sample_id,
        :timestamp,
        :p13_vpp_kw,
        :p30_vpp_kw,
        :q13_vpp_kvar,
        :q30_vpp_kvar,
        :classification,
        :solver_status,
        :replay_status,
        :maximum_absolute_residual,
        :maximum_scaled_residual,
        :minimum_voltage_pu,
        :minimum_voltage_bus,
        :maximum_voltage_pu,
        :maximum_voltage_bus,
        :substation_p_kw,
        :substation_q_kvar,
        :active_losses_kw,
        :reactive_losses_kvar,
        :warm_start_source,
        :runtime_seconds,
        :solver_iterations,
        :replay_iterations,
        :primary_replay_max_voltage_difference_pu,
        :primary_voltage_equation_residual_pu,
    )
end

function evaluate_benchmark(network, profile, indices; count::Integer=SAMPLE_COUNT)
    plan = sample_plan(indices; count=count)
    feasible_starts = Dict(index => NamedTuple[] for index in indices)
    output_rows = NamedTuple[]
    warmup_index = first(indices)
    evaluate_point(network, profile, warmup_index, 0.0, 0.0)
    GC.gc()
    cpu_start = process_cpu_seconds()
    wall_start_ns = time_ns()
    for point in plan
        candidates = feasible_starts[point.profile_index]
        initial_voltage, warm_source = nearest_feasible_start(
            candidates,
            point.p13_vpp_kw,
            point.p30_vpp_kw,
        )
        evaluated = evaluate_point(
            network,
            profile,
            point.profile_index,
            point.p13_vpp_kw,
            point.p30_vpp_kw;
            initial_voltage=initial_voltage,
            warm_start_source=warm_source,
        )
        row = merge((sample_id=point.sample_id,), Base.structdiff(
            evaluated,
            NamedTuple{(:primary_voltage_complex_pu,)}((
                evaluated.primary_voltage_complex_pu,
            )),
        ))
        push!(output_rows, row)
        if evaluated.classification == "FEASIBLE"
            push!(candidates, (
                sample_id=point.sample_id,
                p13_vpp_kw=point.p13_vpp_kw,
                p30_vpp_kw=point.p30_vpp_kw,
                voltage=evaluated.primary_voltage_complex_pu,
            ))
        end
    end
    wall_seconds = (time_ns() - wall_start_ns) / 1e9
    cpu_seconds = process_cpu_seconds() - cpu_start
    return output_rows, wall_seconds, cpu_seconds
end

function write_data_audit(output_directory, profile, indices)
    interpretation = "timezone-naive local wall-clock labels; no UTC conversion; fixed 48 source slots per local-data day; DST behavior inherited from Ausgrid source format"
    row = (
        start_timestamp=Dates.format(
            profile.timestamps[first(indices)],
            dateformat"yyyy-mm-dd HH:MM:SS",
        ),
        end_timestamp=Dates.format(
            profile.timestamps[last(indices)],
            dateformat"yyyy-mm-dd HH:MM:SS",
        ),
        interval_count=length(indices),
        unique_interval_count=length(unique(profile.timestamps[indices])),
        missing_interval_count=count(!=(Minute(30)), diff(profile.timestamps[indices])),
        finite_load_factors=all(isfinite, profile.load_multiplier[indices]),
        finite_pv_factors=all(isfinite, profile.pv_profile[indices]),
        minimum_load_factor=minimum(profile.load_multiplier[indices]),
        maximum_load_factor=maximum(profile.load_multiplier[indices]),
        minimum_pv_factor=minimum(profile.pv_profile[indices]),
        maximum_pv_factor=maximum(profile.pv_profile[indices]),
        timestamp_interpretation=interpretation,
        source_path=profile.source_path,
        source_sha256=profile.source_sha256,
    )
    columns = propertynames(row)
    path = joinpath(output_directory, "stage0_data_audit.csv")
    write_namedtuple_csv(path, columns, [row])
    return path, row
end

function sample_quantile(values::AbstractVector{<:Real}, probability::Real)
    isempty(values) && throw(ArgumentError("quantile input must not be empty"))
    0.0 <= probability <= 1.0 ||
        throw(ArgumentError("quantile probability must lie in [0, 1]"))
    ordered = sort(Float64.(values))
    position = 1.0 + (length(ordered) - 1) * Float64(probability)
    lower = floor(Int, position)
    upper = ceil(Int, position)
    lower == upper && return ordered[lower]
    weight = position - lower
    return (1.0 - weight) * ordered[lower] + weight * ordered[upper]
end

function timing_summary(rows, wall_seconds, cpu_seconds, points_path)
    runtimes = [row.runtime_seconds for row in rows]
    counts = Dict(
        label => count(row -> row.classification == label, rows)
        for label in ("FEASIBLE", "INFEASIBLE_VOLTAGE", "UNKNOWN_SOLVER")
    )
    file_bytes = filesize(points_path)
    header_bytes = length(readline(points_path)) + 2
    mean_row_bytes = (file_bytes - header_bytes) / length(rows)
    coarse_count = 96 * 15 * 15
    dense_count = 96 * 50 * 50
    seconds_per_evaluation = wall_seconds / length(rows)
    average_cores = cpu_seconds / wall_seconds
    return (
        benchmark_evaluations=length(rows),
        benchmark_wall_seconds=wall_seconds,
        median_solve_seconds=sample_quantile(runtimes, 0.50),
        p90_solve_seconds=sample_quantile(runtimes, 0.90),
        maximum_solve_seconds=maximum(runtimes),
        converged_count=count(row -> row.solver_status == "CONVERGED", rows),
        replay_passed_count=count(row -> row.replay_status == "PASSED", rows),
        feasible_count=counts["FEASIBLE"],
        infeasible_voltage_count=counts["INFEASIBLE_VOLTAGE"],
        unknown_solver_count=counts["UNKNOWN_SOLVER"],
        peak_rss_bytes=Sys.maxrss(),
        process_cpu_seconds=cpu_seconds,
        average_process_cores=average_cores,
        cpu_utilization_percent_of_logical_capacity=
            100.0 * average_cores / Sys.CPU_THREADS,
        logical_cpu_count=Sys.CPU_THREADS,
        total_physical_memory_bytes=Sys.total_memory(),
        estimated_21600_wall_seconds=seconds_per_evaluation * coarse_count,
        estimated_240000_wall_seconds=seconds_per_evaluation * dense_count,
        measured_points_file_bytes=file_bytes,
        estimated_mean_raw_row_bytes=mean_row_bytes,
        estimated_21600_raw_bytes=header_bytes + mean_row_bytes * coarse_count,
        estimated_240000_raw_bytes=header_bytes + mean_row_bytes * dense_count,
        parallelization_assessment="safe after serial module initialization; evaluations use immutable feeder inputs and per-call state; merge outputs in deterministic sample order",
    )
end

function write_readme(output_directory, audit, timing)
    path = joinpath(output_directory, "README.md")
    open(path, "w") do io
        println(io, "# DSO-VPP sampled AC voltage-feasible injection map: Stage 0")
        println(io)
        println(io, "This directory contains only the audit and 1,000-evaluation timing pilot.")
        println(io, "The complete 96-interval map has not been launched.")
        println(io)
        println(io, "## Scope and authority")
        println(io)
        println(io, "- Boundary variables are direct active-power injections at buses 13 and 30.")
        println(io, "- Positive values inject into the network; negative values consume from it.")
        println(io, "- Controllable reactive power is zero at both VPP connection points.")
        println(io, "- The primary calculation is the repository's exact radial backward/forward AC solve.")
        println(io, "- Every point is separately replayed with `replay_s1b_interval` and its branch-flow residual audit.")
        println(io, "- The voltage band is 0.90-1.05 p.u., root voltage is 1.00 p.u., base power is 10 MVA, and base voltage is 12.66 kV.")
        println(io, "- Upstream exchange is unconstrained. No thermal or transformer limit is applied.")
        println(io)
        println(io, "## Timestamp audit")
        println(io)
        println(io, "- Interval count: $(audit.interval_count); unique intervals: $(audit.unique_interval_count); missing intervals: $(audit.missing_interval_count).")
        println(io, "- Window: $(audit.start_timestamp) through $(audit.end_timestamp).")
        println(io, "- Interpretation: $(audit.timestamp_interpretation).")
        println(io, "- Load and PV factors are finite: $(audit.finite_load_factors && audit.finite_pv_factors).")
        println(io)
        println(io, "## Benchmark")
        println(io)
        @printf(io, "- Wall time for %d evaluations: %.6f s.\n", timing.benchmark_evaluations, timing.benchmark_wall_seconds)
        @printf(io, "- Per-point solve time: median %.6g s, p90 %.6g s, maximum %.6g s.\n", timing.median_solve_seconds, timing.p90_solve_seconds, timing.maximum_solve_seconds)
        println(io, "- Counts: FEASIBLE=$(timing.feasible_count), INFEASIBLE_VOLTAGE=$(timing.infeasible_voltage_count), UNKNOWN_SOLVER=$(timing.unknown_solver_count).")
        @printf(io, "- Peak process RSS: %.3f MiB.\n", timing.peak_rss_bytes / 2.0^20)
        @printf(io, "- Average CPU: %.3f logical cores (%.2f%% of %d-core logical capacity).\n", timing.average_process_cores, timing.cpu_utilization_percent_of_logical_capacity, timing.logical_cpu_count)
        @printf(io, "- Linear estimate for 21,600 evaluations: %.3f s; raw table %.3f MiB.\n", timing.estimated_21600_wall_seconds, timing.estimated_21600_raw_bytes / 2.0^20)
        @printf(io, "- Linear estimate for 240,000 evaluations: %.3f s; raw table %.3f MiB.\n", timing.estimated_240000_wall_seconds, timing.estimated_240000_raw_bytes / 2.0^20)
        println(io)
        println(io, "The timing estimates are linear extrapolations from this Stage-0 sample and exclude plotting and adaptive-bound discovery.")
        println(io, "No complete map or refinement was run. Explicit user approval is required before Stage 1.")
    end
    return path
end

function run_stage0(repository_root::AbstractString; count::Integer=SAMPLE_COUNT)
    profile = load_profile(repository_root)
    indices = select_pilot_indices(profile)
    network = build_pilot_network()
    output_directory = joinpath(repository_root, "results", "dso_vpp_ac_map_pilot")
    mkpath(output_directory)
    audit_path, audit = write_data_audit(output_directory, profile, indices)
    rows, wall_seconds, cpu_seconds = evaluate_benchmark(
        network,
        profile,
        indices;
        count=count,
    )
    points_path = joinpath(output_directory, "stage0_benchmark_points.csv")
    write_namedtuple_csv(points_path, benchmark_columns(), rows)
    timing = timing_summary(rows, wall_seconds, cpu_seconds, points_path)
    timing_path = joinpath(output_directory, "timing_benchmark.csv")
    write_namedtuple_csv(timing_path, propertynames(timing), [timing])
    readme_path = write_readme(output_directory, audit, timing)

    # The final verdict is reconstructed from the written CSV, not retained state.
    written_lines = readlines(points_path)
    length(written_lines) == count + 1 ||
        error("written benchmark row count mismatch")
    header = split(first(written_lines), ',')
    class_index = findfirst(==("classification"), header)
    class_index === nothing && error("written benchmark classification column is missing")
    written_counts = Dict(
        label => Base.count(
            line -> split(line, ',')[class_index] == label,
            Iterators.drop(written_lines, 1),
        )
        for label in ("FEASIBLE", "INFEASIBLE_VOLTAGE", "UNKNOWN_SOLVER")
    )
    sum(values(written_counts)) == count ||
        error("written classification counts do not cover every benchmark point")
    written_counts["FEASIBLE"] == timing.feasible_count ||
        error("in-memory and written FEASIBLE counts disagree")
    written_counts["INFEASIBLE_VOLTAGE"] == timing.infeasible_voltage_count ||
        error("in-memory and written INFEASIBLE_VOLTAGE counts disagree")
    written_counts["UNKNOWN_SOLVER"] == timing.unknown_solver_count ||
        error("in-memory and written UNKNOWN_SOLVER counts disagree")
    return (
        output_directory=output_directory,
        audit_path=audit_path,
        points_path=points_path,
        timing_path=timing_path,
        readme_path=readme_path,
        timing=timing,
    )
end

end
