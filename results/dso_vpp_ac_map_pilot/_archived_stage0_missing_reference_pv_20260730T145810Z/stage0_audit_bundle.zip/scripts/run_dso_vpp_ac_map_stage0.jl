function main()
    repository_root = normpath(joinpath(@__DIR__, ".."))
    Base.include(
        Main,
        joinpath(repository_root, "src", "benchmark", "dso_vpp_ac_map_stage0.jl"),
    )
    module_ref = Base.invokelatest(getfield, Main, :DSOVPPACMapStage0)
    runner = Base.invokelatest(getfield, module_ref, :run_stage0)
    result = Base.invokelatest(
        runner,
        repository_root,
    )
    timing = result.timing
    println("output_directory=$(result.output_directory)")
    println("benchmark_evaluations=$(timing.benchmark_evaluations)")
    println("benchmark_wall_seconds=$(timing.benchmark_wall_seconds)")
    println("feasible_count=$(timing.feasible_count)")
    println("infeasible_voltage_count=$(timing.infeasible_voltage_count)")
    println("unknown_solver_count=$(timing.unknown_solver_count)")
    println("peak_rss_bytes=$(timing.peak_rss_bytes)")
    println("estimated_21600_wall_seconds=$(timing.estimated_21600_wall_seconds)")
    println("estimated_240000_wall_seconds=$(timing.estimated_240000_wall_seconds)")
end

main()
